from setuptools import setup

setup(name='pymaniprob',
      version='0.1',
      author='Daniel Tait',
      url='http://github.com/danieljtait/pymaniprob',
      license='MIT',
      packages=['pymaniprob'],
      zip_safe=False)
