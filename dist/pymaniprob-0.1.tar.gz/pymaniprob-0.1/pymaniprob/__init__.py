
def message():
    return "Hello, world!"
